from pathlib import Path
from uuid import uuid4
from PIL import Image, UnidentifiedImageError
from fastapi import UploadFile, HTTPException

BASE_DIR = Path(__file__).resolve().parents[1]
UPLOAD_DIR = BASE_DIR / "data" / "uploads"

UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp"}
MAX_FILE_SIZE = 10 * 1024 * 1024  # 10 MB


async def save_uploaded_image(file: UploadFile) -> str:
    """Validate and save an uploaded image. Returns its saved path."""

    if not file.filename:
        raise HTTPException(status_code=400, detail="No image selected.")

    extension = Path(file.filename).suffix.lower()

    if extension not in ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail="Only JPG, JPEG, PNG, and WEBP images are allowed."
        )

    content = await file.read()

    if not content:
        raise HTTPException(status_code=400, detail="The uploaded file is empty.")

    if len(content) > MAX_FILE_SIZE:
        raise HTTPException(
            status_code=413,
            detail="Image size must not exceed 10 MB."
        )

    try:
        from io import BytesIO

        with Image.open(BytesIO(content)) as image:
            image.verify()

    except (UnidentifiedImageError, OSError):
        raise HTTPException(
            status_code=400,
            detail="The uploaded file is not a valid image."
        )

    filename = f"{uuid4().hex}{extension}"
    destination = UPLOAD_DIR / filename

    destination.write_bytes(content)

    return str(destination)


def get_image_path(filename: str) -> Path:
    """Safely find an image inside the upload directory."""

    path = (UPLOAD_DIR / filename).resolve()

    if path.parent != UPLOAD_DIR.resolve():
        raise ValueError("Invalid image filename.")

    if not path.exists():
        raise FileNotFoundError("Uploaded image not found.")

    return path