from pathlib import Path
from uuid import uuid4

from docx import Document
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer
)
from reportlab.lib.units import mm
from pptx import Presentation
from pptx.util import Inches, Pt


BASE_DIR = Path(__file__).resolve().parents[1]
REPORT_DIR = BASE_DIR / "generated" / "reports"

REPORT_DIR.mkdir(parents=True, exist_ok=True)


def split_report(content: str):
    """Split report text into paragraphs."""

    return [
        paragraph.strip()
        for paragraph in content.split("\n")
        if paragraph.strip()
    ]


def generate_pdf(content: str) -> str:
    filename = f"report_{uuid4().hex}.pdf"
    filepath = REPORT_DIR / filename

    document = SimpleDocTemplate(
        str(filepath),
        pagesize=A4,
        rightMargin=22 * mm,
        leftMargin=22 * mm,
        topMargin=22 * mm,
        bottomMargin=22 * mm
    )

    styles = getSampleStyleSheet()
    story = []

    for paragraph in split_report(content):
        safe_text = (
            paragraph
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
        )

        story.append(
            Paragraph(safe_text, styles["BodyText"])
        )
        story.append(Spacer(1, 8))

    document.build(story)

    return str(filepath)


def generate_docx(content: str) -> str:
    filename = f"report_{uuid4().hex}.docx"
    filepath = REPORT_DIR / filename

    document = Document()

    for paragraph in split_report(content):
        document.add_paragraph(paragraph)

    document.save(str(filepath))

    return str(filepath)


def generate_pptx(content: str) -> str:
    filename = f"report_{uuid4().hex}.pptx"
    filepath = REPORT_DIR / filename

    presentation = Presentation()

    paragraphs = split_report(content)

    chunks = [
        paragraphs[index:index + 5]
        for index in range(0, len(paragraphs), 5)
    ]

    if not chunks:
        chunks = [["PrismShift AI Report"]]

    for index, chunk in enumerate(chunks):
        slide = presentation.slides.add_slide(
            presentation.slide_layouts[1]
        )

        slide.shapes.title.text = (
            "PrismShift AI Report"
            if index == 0
            else f"Report - Page {index + 1}"
        )

        text_frame = slide.placeholders[1].text_frame
        text_frame.clear()

        for paragraph_index, text in enumerate(chunk):
            paragraph = (
                text_frame.paragraphs[0]
                if paragraph_index == 0
                else text_frame.add_paragraph()
            )

            paragraph.text = text
            paragraph.font.size = Pt(18)

    presentation.save(str(filepath))

    return str(filepath)


def generate_report(content: str, file_format: str) -> str:
    """Export a report in the requested format."""

    file_format = file_format.lower().strip()

    exporters = {
        "pdf": generate_pdf,
        "docx": generate_docx,
        "pptx": generate_pptx
    }

    if file_format not in exporters:
        raise ValueError("Format must be PDF, DOCX, or PPTX.")

    return exporters[file_format](content)