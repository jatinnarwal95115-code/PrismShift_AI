import ollama
from pathlib import Path

MODEL = "gemma4:latest"


def ask_gemma(prompt: str, image_path: str | None = None) -> str:
    """Send a text prompt, optionally with an image, to Gemma."""

    message = {
        "role": "user",
        "content": prompt
    }

    if image_path:
        path = Path(image_path)

        if not path.exists():
            raise FileNotFoundError(f"Image not found: {image_path}")

        message["images"] = [str(path)]

    try:
        response = ollama.chat(
            model=MODEL,
            messages=[message]
        )

        return response["message"]["content"].strip()

    except Exception as error:
        raise RuntimeError(
            f"Could not connect to Gemma. Make sure Ollama is running "
            f"and {MODEL} is installed. Details: {error}"
        ) from error


def analyze_image(image_path: str, mode: str) -> str:
    """Analyze an uploaded image in Reality or Digital Mode."""

    if mode == "reality":
        prompt = """
You are PrismShift AI's Reality Mode analysis assistant.

Carefully examine the uploaded real-world photograph.

Organize your response under these headings:

1. Visible Evidence
Describe only things that can actually be seen in the photograph.

2. Observed Concerns
Explain any visible damage, obstruction, waste, maintenance issue,
or other concern. Do not exaggerate.

3. Possible Impacts
Describe potential consequences, clearly identifying them as possibilities
rather than confirmed facts.

4. Recommended Actions
Suggest practical next steps.

5. Missing Information
List details that cannot be established from the image alone.

Important:
- Never invent the location, date, measurements, ownership, or cause.
- Do not claim that a person or authority is responsible without evidence.
- Clearly distinguish observations from assumptions.
- Use professional, neutral language.
"""

    elif mode == "digital":
        prompt = """
You are PrismShift AI's Digital Mode visual-design analyst.

Analyze the uploaded design reference.

Use these headings:

1. Design Category
Identify whether it appears to be a poster, website, app interface,
logo, banner, social media graphic, or another design.

2. Overall Visual Style
Describe the visual direction and mood.

3. Colour Palette
Describe the visible main and supporting colours.

4. Layout and Composition
Explain spacing, alignment, positioning, and visual balance.

5. Typography
Describe the visible typography characteristics.
Do not invent exact font names.

6. Visual Hierarchy
Explain what attracts attention first and why.

7. Design Elements
Describe visible shapes, icons, buttons, images, borders, and other elements.

8. Improvement Opportunities
Suggest useful improvements, if appropriate.

9. Reference Summary
Provide a concise summary of the design.

Important:
- Do not invent exact CSS values or font names.
- Do not generate an image, website, SVG, or code.
- This mode is for visual analysis and prompt writing only.
"""

    else:
        raise ValueError("Mode must be 'reality' or 'digital'.")

    return ask_gemma(prompt, image_path)


def generate_digital_prompt(
    image_path: str,
    description: str = ""
) -> str:
    """Generate a detailed reusable prompt from a design reference."""

    prompt = f"""
You are PrismShift AI's Digital Mode prompt-writing assistant.

Study the uploaded reference image and write one detailed,
self-contained prompt that a user can paste into another AI tool.

User's requested changes:
{description or "No additional changes provided."}

Your prompt must describe:
- The type and purpose of the design
- Overall visual style and mood
- Colour palette
- Layout and composition
- Typography characteristics
- Visual hierarchy
- Important design elements
- Spacing and alignment
- The user's requested changes

Preserve the important characteristics of the reference unless
the user specifically requests a change.

Make the final prompt clear, detailed, practical, and ready to copy.

Do not generate the actual image, website, SVG, or code.
Return the final reusable prompt, not an explanation of your process.
"""

    return ask_gemma(prompt, image_path)


def generate_reality_report(
    image_path: str,
    document_type: str,
    author_name: str,
    location: str,
    authority: str,
    additional_points: str = ""
) -> str:
    """Generate a formal Reality Mode document."""

    allowed_types = ["letter", "application", "complaint", "report"]

    if document_type.lower() not in allowed_types:
        raise ValueError(
            "Document type must be letter, application, complaint, or report."
        )

    prompt = f"""
You are PrismShift AI's professional document-writing assistant.

Prepare a formal {document_type} based on the uploaded photograph.

Document details:
Author name: {author_name or "Not provided"}
Location: {location or "Not provided"}
Recipient or authority: {authority or "Not specified"}

Additional points from the user:
{additional_points or "None provided."}

Instructions:
1. Write in clear, formal, respectful language.
2. Explain the issue using only evidence visible in the photograph
   and information supplied by the user.
3. Clearly qualify possible impacts.
4. Never invent dates, measurements, addresses, legal provisions,
   incident history, or responsible parties.
5. Do not claim that an authority has violated a law unless verified.
6. Include a suitable subject and requested action.
7. Include a closing and signature section for the author.

Use a professional document structure appropriate for a {document_type}.
Return the document text only.
"""

    return ask_gemma(prompt, image_path)


def edit_content(
    original_content: str,
    instruction: str,
    content_type: str
) -> str:
    """Revise an existing report or reusable design prompt."""

    if content_type == "report":
        role = (
            "You are editing a formal Reality Mode document. "
            "Keep it factual, professional, and respectful."
        )
    elif content_type == "prompt":
        role = (
            "You are editing a reusable Digital Mode design prompt. "
            "Keep it detailed, clear, and ready to paste into another AI tool. "
            "Do not generate images or code."
        )
    else:
        raise ValueError("content_type must be 'report' or 'prompt'.")

    prompt = f"""
{role}

Original content:
{original_content}

User's requested edit:
{instruction}

Apply the requested edit while preserving all information that
the user did not ask to change.

Return the complete revised content only.
"""

    return ask_gemma(prompt)