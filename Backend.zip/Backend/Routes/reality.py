from pathlib import Path

from fastapi import (
    APIRouter,
    UploadFile,
    File,
    Form,
    HTTPException,
    Depends
)

from fastapi.security import (
    HTTPBearer,
    HTTPAuthorizationCredentials
)

from fastapi.responses import FileResponse

from Backend.services.image_service import save_uploaded_image

from Backend.services.gemma_service import (
    analyze_image,
    generate_reality_report,
    edit_content
)

from Backend.services.report_service import generate_report

from Backend.services.database import (
    create_conversation,
    save_message,
    get_user_conversation,
    REPORT_DIR
)

from Backend.services.auth_service import get_user_from_token


# --------------------------------------------------
# ROUTER CONFIGURATION
# --------------------------------------------------

router = APIRouter(
    prefix="/reality",
    tags=["Reality Mode"]
)

security = HTTPBearer(auto_error=False)


# --------------------------------------------------
# AUTHENTICATION HELPER
# --------------------------------------------------

def get_optional_user(
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    if not credentials:
        return None

    return get_user_from_token(credentials.credentials)


# --------------------------------------------------
# 1. IMAGE ANALYSIS
# --------------------------------------------------

@router.post("/analyze")
async def reality_analyze(
    image: UploadFile = File(...),
    user=Depends(get_optional_user)
):
    image_path = await save_uploaded_image(image)

    try:
        analysis = analyze_image(
            str(image_path),
            "reality"
        )

        conversation_id = None

        if user:
            conversation_id = create_conversation(
                user_id=user["id"],
                title="Reality Mode Analysis",
                mode="reality",
                image_path=str(image_path)
            )

            save_message(
                conversation_id,
                "assistant",
                analysis
            )

        return {
            "success": True,
            "mode": "reality",
            "analysis": analysis,
            "conversation_id": conversation_id
        }

    except Exception as error:
        raise HTTPException(
            status_code=500,
            detail=f"Reality analysis failed: {str(error)}"
        )


# --------------------------------------------------
# 2. GENERATE FORMAL REPORT
# --------------------------------------------------

@router.post("/generate")
async def reality_generate(
    image: UploadFile = File(...),
    document_type: str = Form(...),
    author_name: str = Form(""),
    location: str = Form(""),
    authority: str = Form(""),
    additional_points: str = Form(""),
    user=Depends(get_optional_user)
):
    image_path = await save_uploaded_image(image)

    try:
        # Step 1: Analyze the photograph
        analysis = analyze_image(
            str(image_path),
            "reality"
        )

        # Step 2: Generate the formal document
        report = generate_reality_report(
            image_path=str(image_path),
            document_type=document_type,
            author_name=author_name,
            location=location,
            authority=authority,
            additional_points=additional_points
        )

        conversation_id = None

        if user:
            conversation_id = create_conversation(
                user_id=user["id"],
                title=f"{document_type.title()} - {location or 'New Report'}",
                mode="reality",
                image_path=str(image_path)
            )

            save_message(
                conversation_id,
                "assistant",
                analysis
            )

            save_message(
                conversation_id,
                "assistant",
                report
            )

        return {
            "success": True,
            "mode": "reality",
            "analysis": analysis,
            "document": report,
            "conversation_id": conversation_id
        }

    except ValueError as error:
        raise HTTPException(
            status_code=400,
            detail=str(error)
        )

    except Exception as error:
        raise HTTPException(
            status_code=500,
            detail=f"Report generation failed: {str(error)}"
        )


# --------------------------------------------------
# 3. EDIT REPORT
# --------------------------------------------------

@router.post("/edit")
async def reality_edit(
    instruction: str = Form(...),
    content: str = Form(...),
    conversation_id: int | None = Form(None),
    user=Depends(get_optional_user)
):
    if not instruction.strip() or not content.strip():
        raise HTTPException(
            status_code=400,
            detail="Content and editing instruction are required."
        )

    if conversation_id is not None:
        if not user:
            raise HTTPException(
                status_code=401,
                detail="Please log in to edit a saved conversation."
            )

        conversation = get_user_conversation(
            conversation_id,
            user["id"]
        )

        if not conversation or conversation["mode"] != "reality":
            raise HTTPException(
                status_code=404,
                detail="Reality conversation not found."
            )

    try:
        revised_report = edit_content(
            original_content=content,
            instruction=instruction,
            content_type="report"
        )

        if conversation_id is not None:
            save_message(
                conversation_id,
                "user",
                instruction
            )

            save_message(
                conversation_id,
                "assistant",
                revised_report
            )

        return {
            "success": True,
            "revised_document": revised_report,
            "conversation_id": conversation_id
        }

    except Exception as error:
        raise HTTPException(
            status_code=500,
            detail=f"Report editing failed: {str(error)}"
        )


# --------------------------------------------------
# 4. EXPORT REPORT
# --------------------------------------------------

@router.post("/export")
def reality_export(
    content: str = Form(...),
    file_format: str = Form(...)
):
    try:
        file_format = file_format.lower().strip()

        if file_format not in ["pdf", "docx", "pptx"]:
            raise HTTPException(
                status_code=400,
                detail="Choose PDF, DOCX, or PPTX."
            )

        filepath = Path(
            generate_report(content, file_format)
        ).resolve()

        if filepath.parent != REPORT_DIR.resolve():
            raise HTTPException(
                status_code=400,
                detail="Invalid report path."
            )

        media_types = {
            "pdf": "application/pdf",
            "docx": (
                "application/vnd.openxmlformats-officedocument."
                "wordprocessingml.document"
            ),
            "pptx": (
                "application/vnd.openxmlformats-officedocument."
                "presentationml.presentation"
            )
        }

        return FileResponse(
            path=str(filepath),
            filename=f"PrismShift_Reality_Report.{file_format}",
            media_type=media_types[file_format]
        )

    except HTTPException:
        raise

    except Exception as error:
        raise HTTPException(
            status_code=500,
            detail=f"Report export failed: {str(error)}"
        )