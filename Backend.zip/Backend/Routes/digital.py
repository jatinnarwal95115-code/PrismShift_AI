from fastapi import (
    APIRouter,
    UploadFile,
    File,
    Form,
    HTTPException,
    Depends
)

from fastapi.security import (
    HTTPBearer,
    HTTPAuthorizationCredentials
)

from Backend.services.image_service import save_uploaded_image

from Backend.services.gemma_service import (
    analyze_image,
    generate_digital_prompt,
    edit_content
)

from Backend.services.database import (
    create_conversation,
    save_message,
    get_user_conversation
)

from Backend.services.auth_service import get_user_from_token


# --------------------------------------------------
# ROUTER CONFIGURATION
# --------------------------------------------------

router = APIRouter(
    prefix="/digital",
    tags=["Digital Mode"]
)

security = HTTPBearer(auto_error=False)


# --------------------------------------------------
# AUTHENTICATION HELPER
# --------------------------------------------------

def get_optional_user(
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    if not credentials:
        return None

    return get_user_from_token(credentials.credentials)


# --------------------------------------------------
# 1. IMAGE ANALYSIS
# --------------------------------------------------

@router.post("/analyze")
async def digital_analyze(
    image: UploadFile = File(...),
    user=Depends(get_optional_user)
):
    image_path = await save_uploaded_image(image)

    try:
        analysis = analyze_image(
            str(image_path),
            "digital"
        )

        conversation_id = None

        if user:
            conversation_id = create_conversation(
                user_id=user["id"],
                title="Digital Design Analysis",
                mode="digital",
                image_path=str(image_path)
            )

            save_message(
                conversation_id,
                "assistant",
                analysis
            )

        return {
            "success": True,
            "mode": "digital",
            "analysis": analysis,
            "conversation_id": conversation_id
        }

    except Exception as error:
        raise HTTPException(
            status_code=500,
            detail=f"Design analysis failed: {str(error)}"
        )


# --------------------------------------------------
# 2. GENERATE REUSABLE DESIGN PROMPT
# --------------------------------------------------

@router.post("/generate")
async def digital_generate(
    image: UploadFile = File(...),
    description: str = Form(""),
    user=Depends(get_optional_user)
):
    image_path = await save_uploaded_image(image)

    try:
        generated_prompt = generate_digital_prompt(
            image_path=str(image_path),
            description=description
        )

        conversation_id = None

        if user:
            conversation_id = create_conversation(
                user_id=user["id"],
                title="Digital Design Prompt",
                mode="digital",
                image_path=str(image_path)
            )

            if description.strip():
                save_message(
                    conversation_id,
                    "user",
                    description
                )

            save_message(
                conversation_id,
                "assistant",
                generated_prompt
            )

        return {
            "success": True,
            "mode": "digital",
            "generated_prompt": generated_prompt,
            "conversation_id": conversation_id
        }

    except Exception as error:
        raise HTTPException(
            status_code=500,
            detail=f"Prompt generation failed: {str(error)}"
        )


# --------------------------------------------------
# 3. EDIT GENERATED PROMPT
# --------------------------------------------------

@router.post("/edit")
async def digital_edit(
    instruction: str = Form(...),
    content: str = Form(...),
    conversation_id: int | None = Form(None),
    user=Depends(get_optional_user)
):
    if not instruction.strip() or not content.strip():
        raise HTTPException(
            status_code=400,
            detail="Prompt and editing instruction are required."
        )

    if conversation_id is not None:
        if not user:
            raise HTTPException(
                status_code=401,
                detail="Please log in to edit a saved conversation."
            )

        conversation = get_user_conversation(
            conversation_id,
            user["id"]
        )

        if not conversation or conversation["mode"] != "digital":
            raise HTTPException(
                status_code=404,
                detail="Digital conversation not found."
            )

    try:
        revised_prompt = edit_content(
            original_content=content,
            instruction=instruction,
            content_type="prompt"
        )

        if conversation_id is not None:
            save_message(
                conversation_id,
                "user",
                instruction
            )

            save_message(
                conversation_id,
                "assistant",
                revised_prompt
            )

        return {
            "success": True,
            "revised_prompt": revised_prompt,
            "conversation_id": conversation_id
        }

    except Exception as error:
        raise HTTPException(
            status_code=500,
            detail=f"Prompt editing failed: {str(error)}"
        )